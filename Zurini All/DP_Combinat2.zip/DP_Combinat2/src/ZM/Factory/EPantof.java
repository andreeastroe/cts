package ZM.Factory;

public enum EPantof {
	CIZMA, GHEATA
}
