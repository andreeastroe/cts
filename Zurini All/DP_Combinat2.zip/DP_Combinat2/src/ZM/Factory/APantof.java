package ZM.Factory;

public abstract class APantof {
	protected int marime;
	
	public abstract String getInfo();
	public abstract double calculMateriePrima();
	
	public void setMarime(int marime) {
		this.marime = marime;
	}
	
	
}
