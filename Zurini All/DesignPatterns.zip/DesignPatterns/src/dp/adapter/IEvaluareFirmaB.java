package dp.adapter;

public interface IEvaluareFirmaB {
	void analizeazaClientFirmaB(Client client);
}
