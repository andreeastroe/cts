package dp.flyweight;

public interface IBonPrintabil {
	public void priteazaBon(DateBon bon);
}
