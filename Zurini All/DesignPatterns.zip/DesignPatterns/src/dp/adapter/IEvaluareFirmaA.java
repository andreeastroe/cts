package dp.adapter;

public interface IEvaluareFirmaA {
	void analizeazaClientFirmaA(int costTotalEvenimente);
}
