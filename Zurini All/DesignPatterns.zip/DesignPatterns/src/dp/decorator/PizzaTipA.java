package dp.decorator;

public class PizzaTipA extends APizza{
	
	@Override
	String getComponente() {
		return "blat, sos rosii, branza, sunca";
	}

	@Override
	float getPret() {
		// TODO Auto-generated method stub
		return 20;
	}

}
