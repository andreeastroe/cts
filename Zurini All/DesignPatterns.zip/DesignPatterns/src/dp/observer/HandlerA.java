package dp.observer;

public class HandlerA implements Handler{

	@Override
	public void act() {
		System.out.println("Actiune handler A");
	}

}
