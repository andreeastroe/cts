package dp.observer;

public interface Handler {
	public void act();
}
