package dp.template;

public class TestTemplate {

	public static void main(String[] args) {
		AWorkFlow workFlow = new WorkFlowA();
		
		workFlow.work();
	}

}
