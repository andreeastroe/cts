package cts.examen.s3.pattern2;

public class Locuinta {
	private int cod;
	private float mp;
	private int nrCamere;
	private float pret;
	
	public Locuinta(int cod, float mp, int nrCamere, float pret) {
		this.cod = cod;
		this.mp = mp;
		this.nrCamere = nrCamere;
		this.pret = pret;
	}

	public int getCod() {
		return cod;
	}

	public float getMp() {
		return mp;
	}

	public void setNrCamere(int nrCamere) {
		this.nrCamere = nrCamere;
	}

	public float getPret() {
		return pret;
	}
}
