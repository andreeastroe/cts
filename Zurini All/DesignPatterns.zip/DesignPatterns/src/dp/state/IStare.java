package dp.state;

public interface IStare {
	void act(String mesaj);
}
