package dp.proxy;

public interface IShow {
	void afisareImagine();
}
