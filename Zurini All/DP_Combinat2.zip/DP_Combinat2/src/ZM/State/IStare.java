package ZM.State;

public interface IStare {
	void getInfoComanda();
}
