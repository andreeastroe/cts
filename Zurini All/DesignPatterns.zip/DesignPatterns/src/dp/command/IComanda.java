package dp.command;

public interface IComanda {
	void prelucreaza();
}
