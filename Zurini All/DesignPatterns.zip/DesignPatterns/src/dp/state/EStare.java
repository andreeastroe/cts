package dp.state;

public enum EStare {
	CONCEDIU, TURA, PAUZA
}
