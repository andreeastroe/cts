package dp.factory;

public enum EAngajat {
	OSPATAR, BUCATAR
}
