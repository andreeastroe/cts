package dp.flyweight;

public enum ETipBon {
	FORMAT1, FORMAT2, FORMAT3
}
