package dp.strategy;

public interface IStrategy {
	int procesare(int[] valori);
}
