package dp.flyweight;

public class DateBon {
	private float pretConsumatie;

	public DateBon(float pretConsumatie) {
		super();
		this.pretConsumatie = pretConsumatie;
	}

	public float getPretConsumatie() {
		return pretConsumatie;
	}
	
}
