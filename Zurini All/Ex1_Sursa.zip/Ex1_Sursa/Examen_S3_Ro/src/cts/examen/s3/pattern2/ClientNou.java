package cts.examen.s3.pattern2;

public class ClientNou {
	private String nume;
	private float creditMaximAccordat;
	
	public ClientNou(String nume, float creditMaximAccordat) {
		this.nume = nume;
		this.creditMaximAccordat = creditMaximAccordat;
	}

	public float getCreditMaximAccordat() {
		return creditMaximAccordat;
	}
}
