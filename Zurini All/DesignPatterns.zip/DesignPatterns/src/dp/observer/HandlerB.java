package dp.observer;

public class HandlerB implements Handler{

	@Override
	public void act() {
		System.out.println("Actiune Handler B");
	}

}
