package dp.template;

public class WorkFlowA extends AWorkFlow{

	@Override
	public void act1() {
		System.out.println("Actiune 1 A");
	}

}
