package dp.command;

public enum ETipComanda {
	COMANDA_PIZZA, COMANDA_PASTE
}
